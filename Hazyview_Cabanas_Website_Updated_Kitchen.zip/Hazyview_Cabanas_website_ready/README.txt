Hazyview Cabanas website

Upload index.html to your GitHub repository. It is self-contained and already includes the website photos.

After upload: Settings -> Pages -> Deploy from a branch -> main -> / (root) -> Save.
